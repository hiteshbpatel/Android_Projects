/** Automatically generated file. DO NOT MODIFY */
package com.example.achartengineexample;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}