package com.example.shriyanshu.expandablerecyclerviewexampleandroid;

public class Movies {

    private String mName;

    public Movies(String name) {
        mName = name;
    }

    public String getName() {
        return mName;
    }
}
