package com.example.multipanefragmentexampleandroid;

public class MovieData {
	
	static String[] Movie = {
        "Don't Breathe",
        "Suicide Squad",
        "Kubo and the Two Strings",
        "Pete's Dragon",
        "Sausage Party",
        "War Dogs"
    };

    static String[] MovieDetails = {
        "Don't Breathe\n\nHoping to walk away with a massive fortune, a trio of thieves break into the house of a blind man who isn't as helpless as he seems.",
        "Suicide Squad\n\nA secret government agency recruits some of the most dangerous incarcerated criminals to form a defensive task force, with their first case leading to a potential apocalypse.",
        "Kubo and the Two Strings\n\nA young boy named Kubo must locate a magical suit of armor worn by his late father in order to defeat a vengeful spirit from the past.",
        "Pete's Dragon\n\nThe adventures of an orphaned boy named Pete and his best friend Elliot, who just so happens to be a dragon.",
        "Sausage Party\n\nA sausage strives to discover the truth about his existence.",
        "War Dogs\n\nBased on the true story of two young men, David Packouz and Efraim Diveroli, who won a $300 million contract from the Pentagon to arm America's allies in Afghanistan. "
    };
}
